;(function () {
    'use strict';

    angular.module('blocks.request', [
        'factory.url',
        'factory.request'
    ]);

})();