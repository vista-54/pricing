;(function () {
    'use strict';

    angular.module('blocks.services', [
        'service.weather'
    ]);

})();