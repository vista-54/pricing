;(function () {
    'use strict';

    angular.module('blocks.directives', [
    ]);

})();