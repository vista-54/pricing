
;(function () {
    'use strict';

    angular.module('blocks.filters', [
        'filter.example'
    ]);

})();


