;(function () {
    'use strict';
    angular.module('app')
        .controller('LoginController', LoginController);

    function LoginController() {
        let vm = this;
    }
})();